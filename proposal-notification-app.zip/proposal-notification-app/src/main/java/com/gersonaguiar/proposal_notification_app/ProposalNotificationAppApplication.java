package com.gersonaguiar.proposal_notification_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProposalNotificationAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProposalNotificationAppApplication.class, args);
	}

}
