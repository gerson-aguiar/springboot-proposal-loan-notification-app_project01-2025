package com.gersonaguiar.proposal_notification_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProposalNotificationAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
